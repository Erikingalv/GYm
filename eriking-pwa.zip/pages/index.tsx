
import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ScrollArea } from "@/components/ui/scroll-area";
import { motion } from "framer-motion";
import { Checkbox } from "@/components/ui/checkbox";

const mensajesMotivacionales = [
  "¡Hoy es un gran día para superarte! 💪",
  "Sigue empujando tus límites. Tú puedes. 🔥",
  "Cada repetición cuenta. Haz que valga. 🏋️",
  "No te detengas, estás más cerca de tu meta. 🎯",
  "Eriking nunca se rinde. 👑"
];

const rutina = {
  "Día 1 🏋️ Hombros y Pantorrillas": [
    { "texto": "Hombro y Pantorrillas", "imagen": "/images/día_1_1.jpg" },
    { "texto": "1:- Sentado en banco horizontal...", "imagen": "/images/día_1_2.jpg" }
  ],
  "Día 2 💪 Espalda y Bíceps": [
    { "texto": "Espalda y Bíceps", "imagen": "/images/día_2_1.jpg" },
    { "texto": "Remo con máquina Smith...", "imagen": "/images/día_2_2.jpg" }
  ],
  "Día 3 🦵 Cuádriceps": [
    { "texto": "Prensa a una pierna + hack", "imagen": "/images/día_3_1.jpg" }
  ],
  "Día 4 🏋️ Hombros y Pantorrillas": [
    { "texto": "Laterales + Arnold Press", "imagen": "/images/día_4_1.jpg" }
  ],
  "Día 5 💪 Bíceps y Tríceps": [
    { "texto": "Serie gigante + press francés", "imagen": "/images/día_5_1.jpg" }
  ],
  "Día 6 🍑 Femoral y Glúteos": [
    { "texto": "Jefferson + glúteo en máquina", "imagen": "/images/día_6_1.jpg" }
  ],
  "Día 7 ❤️ Pecho": [
    { "texto": "Press inclinado + fondos", "imagen": "/images/día_7_1.jpg" }
  ]
};

export default function RutinaApp() {
  const [completados, setCompletados] = useState({});
  const [mostrarImagen, setMostrarImagen] = useState({});
  const [mensaje, setMensaje] = useState("");
  const [mostrarInicio, setMostrarInicio] = useState(true);

  useEffect(() => {
    const aleatorio = Math.floor(Math.random() * mensajesMotivacionales.length);
    setMensaje(mensajesMotivacionales[aleatorio]);
    const timeout = setTimeout(() => setMostrarInicio(false), 2500);
    return () => clearTimeout(timeout);
  }, []);

  const toggleCompletado = (dia, index) => {
    setCompletados(prev => ({ ...prev, [dia + index]: !prev[dia + index] }));
  };

  const toggleImagen = (dia, index) => {
    setMostrarImagen(prev => ({ ...prev, [dia + index]: !prev[dia + index] }));
  };

  const getProgresoDia = (dia) => {
    const total = rutina[dia].length;
    const hechos = rutina[dia].filter((_, i) => completados[dia + i]).length;
    return Math.round((hechos / total) * 100);
  };

  if (mostrarInicio) {
    return (
      <div className="flex items-center justify-center h-screen text-center px-6">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8 }}
          className="text-xl font-semibold text-muted-foreground"
        >
          {mensaje}
        </motion.div>
      </div>
    );
  }

  return (
    <div className="p-4">
      <h1 className="text-2xl font-bold mb-4 text-center">Eriking - Rutina Semanal</h1>
      <Tabs defaultValue={Object.keys(rutina)[0]} className="w-full">
        <TabsList className="overflow-x-auto flex-nowrap whitespace-nowrap rounded-xl bg-muted p-1">
          {Object.keys(rutina).map(dia => (
            <TabsTrigger key={dia} value={dia} className="min-w-max px-4 py-1 text-sm">
              {dia}
            </TabsTrigger>
          ))}
        </TabsList>

        {Object.entries(rutina).map(([dia, ejercicios]) => (
          <TabsContent key={dia} value={dia}>
            <div className="mb-2">
              <div className="text-sm text-muted-foreground">Progreso: {getProgresoDia(dia)}%</div>
              <div className="w-full bg-gray-200 rounded-full h-2.5 mt-1">
                <div
                  className="bg-green-500 h-2.5 rounded-full transition-all duration-500"
                  style={{ width: `${getProgresoDia(dia)}%` }}
                ></div>
              </div>
            </div>
            <ScrollArea className="h-[70vh] pr-2">
              {ejercicios.map((ejercicio, index) => (
                <motion.div
                  key={dia + index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.02 }}
                >
                  <Card
                    className={`mb-3 transition-opacity duration-300 ease-in-out ${completados[dia + index] ? "opacity-40" : ""}`}
                  >
                    <CardContent
                      className="p-4 text-sm cursor-pointer"
                      onClick={() => toggleImagen(dia, index)}
                    >
                      <div className="flex items-center gap-2">
                        <Checkbox
                          checked={completados[dia + index] || false}
                          onCheckedChange={() => toggleCompletado(dia, index)}
                        />
                        <span>{ejercicio.texto}</span>
                      </div>
                      {mostrarImagen[dia + index] && (
                        <div className="mt-3">
                          <img
                            src={ejercicio.imagen}
                            alt={`Ejercicio ${index + 1}`}
                            className="rounded-lg shadow w-full max-w-md"
                          />
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </ScrollArea>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
